import java.util.Vector;
import java.util.Scanner;

public class TO3_2101629142 {
	public static int input;
	public static String nama;
	public static String pass;
	public static int index=-1;
	public static String newlogin;
	public static String newpass;
	public static Vector vn = new Vector();
	public static Vector vp = new Vector();
	
	public static void menu()
	{	
		Scanner in = new Scanner(System.in);
		do
		{
		System.out.println("Binus Banking System");
		System.out.println("=====================");
		System.out.println("1.Create User");
		System.out.println("2.Login");
		System.out.println("3.Logout");
		System.out.println("4.Delete User");
		System.out.println("5.Show User");
		System.out.println("6.Exit");
		System.out.print("Menu : ");
		input=in.nextInt();
		}while(input <1 || input >6);
		
		if(input==1)
		{
			create();
		}
		else if(input==2)
		{
			login();
		}
		else if(input==3)
		{
			logout();
		}
		else if(input==4)
		{
			delete();
		}
		else if(input==5)
		{
			show();
		}
		else if(input==6)
		{
			System.exit(1);
		}
	}
	public static void create()
	{
		
		Scanner in = new Scanner(System.in);
		System.out.print("Username :");
		nama=in.nextLine();
		vn.add(nama);
		System.out.print("Password :");
		pass=in.nextLine();
		vp.add(pass);
		menu();
	}
	public static void login()
	{
		Scanner in = new Scanner(System.in);
		String hold;
		String Lu;
		String Lp;
		
		
		do
		{
		System.out.print("Username :");
		Lu=in.next();
			for(int i=0;i<=vn.size()-1;i++)
			{
				if(vn.get(i).equals(Lu))
				{
					index=i;
				}
			}
		}while(index==-1);
		
		do
		{
		System.out.print("Password :");
		Lp=in.next();
		}while(!Lp.equals(vp.get(index)));
		System.out.println("Active : "+Lu);
		newlogin=Lu;
		
		hold=in.nextLine();
		menu();
	}
	
	public static void logout()
	{
		Scanner in = new Scanner(System.in);
		String hold;
		index=-1;
		hold=in.nextLine();
		menu();
	}
	
	public static void delete()
	{
	
		Scanner in = new Scanner(System.in);
		String hold;
		System.out.print("Input username to be deleted: ");
		nama=in.next();
		
		vn.remove(nama);
		System.out.println(nama+"'s Account has been deleted");
		index--;
		hold=in.nextLine();
		menu();
	}
	
	public static void show()
	{
		
		Scanner in = new Scanner(System.in);
		System.out.println("List Users");
		System.out.println("================");
		String hold;
		
		for(int i=0;i<=vn.size()-1;i++)
		{
			System.out.println(vn.get(i));
		}
		hold=in.nextLine();
		menu();
		
	}
	public static void main(String[] args) 
	{
		menu();
	}
	

}
