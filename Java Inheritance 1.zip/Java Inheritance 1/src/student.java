
public class student {
	public String NIM;
	public String nama;
	public String phone;
	
	public student(String nIM, String nama, String phone)
	{
		NIM = nIM;
		this.nama = nama;
		this.phone = phone;
	}

	public String getNIM() {
		return NIM;
	}

	public void setNIM(String nIM) {
		NIM = nIM;
	}

	public String getNama() {
		return nama;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
}
