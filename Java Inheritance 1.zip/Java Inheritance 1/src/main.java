import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;
public class main {
	public static int input;
	public static ArrayList<student> stu = new  ArrayList<student>();
	
	public static void menu()
	{
		Scanner sc = new Scanner(System.in);
		do
		{
			System.out.println("Student Management System");
			System.out.println("===========================");
			System.out.println("1. Add Student");
			System.out.println("2. Delete Student");
			System.out.println("3. View Student");
			System.out.println("4. Exit");
			System.out.print("Input: ");
			input=sc.nextInt();
		}while(input <1 ||input>4);
		
		if(input==1)
		{
			add();
		}
		else if(input==2)
		{
			delete();
		}
		else if(input==3)
		{
			view();
		}
		else if(input==4)
		{
			exit();
		}
	}
	
	public static void add()
	{
		String holdNIM;
		Scanner sc = new Scanner(System.in);
		do
		{
		System.out.println("NIM (10 Digits): ");
		 holdNIM=sc.nextLine();
		}while(holdNIM.length() != 10);
		
		System.out.println("Name : ");
		String holdnama=sc.nextLine();
		
		System.out.println("Phone Number : ");
		String holdphone=sc.nextLine();
			
		stu.add(new student(holdNIM,holdnama,holdphone));
		
		menu();
	}
	public static void delete()
	{
		Scanner sc= new Scanner(System.in);
		String holdnim;
		String hold;
		
		System.out.print("Username :");
		holdnim=sc.next();
			for(student x : stu)
			{
				if(x.NIM.equals(holdnim))
				{
					stu.remove(x);
					System.out.println(x.nama+"("+holdnim+")"+"has been deleted");
					hold=sc.nextLine();
					menu();
				}
				else
				{
					System.out.println(holdnim+" you entered is not found!");
					hold=sc.nextLine();
					menu();
				}
			}
		
	}
	public static void view()
	{
		Scanner sc = new Scanner(System.in);
		String hold;
		System.out.println("List of student:");
		System.out.println("======================");
		
		for(student x : stu)
		{
			System.out.println(x.nama);
		}
		
		hold=sc.nextLine();
		menu();
	}
	public static void exit()
	{
		System.exit(1);
	}
	public static void main(String[] args) {
		menu();
	}

}
