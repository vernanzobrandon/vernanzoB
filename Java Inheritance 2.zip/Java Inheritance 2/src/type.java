
public class type {
	public int capacity;
	public int speed;
	public String nama;

	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public String getNama() {
		return nama;
	}
	public void setNama(String nama) {
		this.nama = nama;
	}
	public type(int capacity, int speed, String nama) {
		super();
		this.capacity = capacity;
		this.speed = speed;
		this.nama = nama;
	}

}
