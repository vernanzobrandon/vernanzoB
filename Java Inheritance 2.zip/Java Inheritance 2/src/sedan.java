
public class sedan extends type{

	public sedan(int capacity, int speed, String nama) {
		super(capacity, speed, nama);
		// TODO Auto-generated constructor stub
	}

}
