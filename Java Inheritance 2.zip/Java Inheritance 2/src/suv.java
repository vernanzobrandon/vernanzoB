
public class suv extends type {

	public suv(int capacity, int speed, String nama) {
		super(capacity, speed, nama);
		// TODO Auto-generated constructor stub
	}

}
