import java.util.Scanner;
import java.util.Vector;

public class main {
	public static int input1;
	public static int input2;
	public static Vector<jeep> jeep1 = new Vector<jeep>();
	public static Vector<suv> suv1 = new Vector<suv>();
	public static Vector<sedan> sedan1 = new Vector<sedan>();
	
	public static void menu()
	{
		Scanner sc = new Scanner(System.in);
		do
		{
			System.out.println("SHOWROOM");
			System.out.println("======================");
			System.out.println("1. Buy");
			System.out.println("2. Show");
			System.out.println("3. Exit");
			System.out.print("Input: ");
			input1=sc.nextInt();
		}while(input1 < 1 || input1 >3);
		
		if(input1==1)
		{
			buy();
		}
		else if(input1==2)
		{
			show();
		}
		else if(input1==3)
		{
			System.exit(1);
		}
	}
	public static void buy()
	{
		Scanner sc = new Scanner(System.in);
		String namajeep,namasuv,namasedan;
		do
		{
		System.out.println("1. Jeep");
		System.out.println("2. SUV");
		System.out.println("3. Sedan");
		System.out.print("Input : ");
		input2=sc.nextInt();
		}while(input2 <1 || input2 >3);
		
		if(input2==1)
		{
			System.out.print("Car's name : ");
			namajeep=sc.next();
			jeep1.add(new jeep(30,120,namajeep));
			menu();
		}
		else if(input2==2)
		{
			System.out.print("Car's name : ");
			namasuv=sc.next();
			suv1.add(new suv(15,100,namasuv));
			menu();
		}
		else if(input2==3)
		{
			System.out.print("Car's name : ");
			namasedan=sc.next();
			sedan1.add(new sedan(10,120,namasedan));
			menu();
		}
		
		
	}
	public static void show()
	{
		Scanner sc = new Scanner(System.in);
		String hold;
		
		System.out.println("List car");
		System.out.println("======================");
		System.out.println("Jeep");
		System.out.println("======================");
		for(jeep x : jeep1)
		{
			System.out.println(x.nama);
		}
		System.out.println("\n\n\n\n");
		System.out.println("======================");
		System.out.println("SUV");
		System.out.println("======================");
		for(suv y : suv1)
		{
			System.out.println(y.nama);
		}
		System.out.println("\n\n\n\n");
		System.out.println("======================");
		System.out.println("Sedan");
		System.out.println("======================");
		for(sedan z : sedan1)
		{
			System.out.println(z.nama);
		}
		System.out.println("\n\n\n\n");
		System.out.println("======================");
		hold=sc.nextLine();
		menu();
	}
	public static void main(String[] args) {
		menu();
	}
}

