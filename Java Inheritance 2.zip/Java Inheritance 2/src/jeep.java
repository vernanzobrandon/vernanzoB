
public class jeep extends type{
	
	public jeep(int capacity, int speed, String nama) {
		super(capacity, speed, nama);
		// TODO Auto-generated constructor stub
	}
	
}
